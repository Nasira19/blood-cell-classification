# Hematovision: Blood Cell Classification using Transfer Learning
This project classifies blood cells using pretrained CNN models like ResNet50.
