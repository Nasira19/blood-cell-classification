// Optional JavaScript functions for interactivity
console.log("Hematovision - Blood Cell Classifier Loaded");
